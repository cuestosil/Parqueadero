package datos;

import java.io.Serializable;

/**
 *
 * @author TP303
 */
public enum Opcion implements Serializable{
    INGRESO,SALIDA;
}
