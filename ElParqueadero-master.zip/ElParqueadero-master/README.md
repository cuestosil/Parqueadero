# ElParqueadero
Gestion del parqueadero con uso de Jcalendar-JDateChooser, por medio de una lista que va generando filas con los datos del conductor, identificacion, placa y la 
fecha y hora de ingreso al parqueadero.


![parqueadero2](https://user-images.githubusercontent.com/99418889/164024308-d183463c-25be-4966-91f4-4d20a6ca8776.png)

